"""Agent CLI backends for rewardkit judge evaluation."""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any, override

if TYPE_CHECKING:
    from rewardkit.models import MCPServerConfig

logger = logging.getLogger(__name__)

_REGISTRY: dict[str, type[AgentCLI]] = {}


def force_oauth() -> bool:
    """Whether to prefer a subscription OAuth token over an API key when both are set."""
    return os.environ.get("REWARDKIT_FORCE_OAUTH", "").strip().lower() in (
        "1",
        "true",
        "yes",
    )


class AgentCLI:
    """Base class for agent CLI backends.

    Subclass and call ``register_agent()`` to make an agent available as a TOML judge.
    """

    name: str
    cli_name: str
    install_script: str

    def build_command(
        self,
        prompt: str,
        schema: dict[str, Any],
        allowed_tools: tuple[str, ...] = (),
        cwd: str | None = None,
    ) -> list[str]:
        """*cwd* is the directory the subprocess will actually be launched in
        (``_arun_agent_call`` always passes ``cwd=`` to
        ``asyncio.create_subprocess_exec``) -- most backends don't need it
        (they honor the OS process cwd as their implicit workspace root), but
        a backend that doesn't (see AntigravityCLI) needs the resolved
        absolute path here, before the subprocess exists, to pass as an
        explicit workspace flag.
        """
        raise NotImplementedError

    def _mcp_add_args(self, server: MCPServerConfig) -> list[str]:
        """Args after ``<cli> mcp add`` to register *server* (backend-specific)."""
        raise NotImplementedError

    @staticmethod
    def _stdio_mcp_add_args(server: MCPServerConfig) -> list[str]:
        return [server.name, "--", server.command or "", *server.args]

    def add_mcp_servers(
        self, servers: tuple[MCPServerConfig, ...], cwd: str | None = None
    ) -> None:
        """Register each MCP server via ``<cli> mcp add``.

        CLI reference: claude https://code.claude.com/docs/en/mcp,
        codex https://developers.openai.com/codex/mcp.
        """
        for server in servers:
            args = [os.path.expandvars(arg) for arg in self._mcp_add_args(server)]
            cmd = [self.cli_name, "mcp", "add", *args]
            proc = subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)
            # Re-adding an already-registered server exits non-zero; tolerate it
            # so several judges may declare the same server.
            if (
                proc.returncode != 0
                and "already exists" not in (proc.stdout + proc.stderr).lower()
            ):
                raise subprocess.CalledProcessError(
                    proc.returncode, cmd, output=proc.stdout, stderr=proc.stderr
                )

    def model_args(self, model: str) -> list[str]:
        return ["--model", model]

    def parse_output(self, raw: str) -> str:
        return raw

    def cleanup(self) -> None:
        pass

    def ensure_installed(self) -> None:
        if shutil.which(self.cli_name):
            return
        logger.info("Installing %s...", self.cli_name)
        subprocess.run(
            ["bash", "-c", self.install_script],
            check=True,
            capture_output=True,
        )
        local_bin = str(Path.home() / ".local" / "bin")
        if local_bin not in os.environ.get("PATH", ""):
            os.environ["PATH"] = f"{local_bin}:{os.environ.get('PATH', '')}"
        if not shutil.which(self.cli_name):
            raise FileNotFoundError(
                f"Agent CLI '{self.cli_name}' not found after install attempt"
            )


def register_agent(cls: type[AgentCLI]) -> None:
    _REGISTRY[cls.name] = cls


def get_agent(name: str) -> AgentCLI:
    """Return a fresh instance of the agent backend for *name*."""
    try:
        return _REGISTRY[name]()
    except KeyError:
        known = ", ".join(sorted(_REGISTRY)) or "(none)"
        raise ValueError(f"Unknown agent '{name}'. Known agents: {known}") from None


def known_agents() -> frozenset[str]:
    return frozenset(_REGISTRY)


class ClaudeCodeCLI(AgentCLI):
    name = "claude-code"
    cli_name = "claude"
    install_script = (
        "set -eu; "
        "if command -v apk >/dev/null 2>&1; then"
        "  npm install -g @anthropic-ai/claude-code;"
        " else"
        "  set -o pipefail;"
        "  curl -fsSL https://claude.ai/install.sh | bash;"
        " fi && "
        'export PATH="$HOME/.local/bin:$PATH" && '
        "claude --version"
    )

    @override
    def build_command(
        self,
        prompt: str,
        schema: dict[str, Any],
        allowed_tools: tuple[str, ...] = (),
        cwd: str | None = None,
    ) -> list[str]:
        # cwd unused: claude -p honors the subprocess's own OS cwd as its
        # implicit workspace root.
        cmd = [
            "claude",
            "-p",
            prompt,
            "--output-format",
            "json",
            "--json-schema",
            json.dumps(schema),
        ]
        # claude -p will not call MCP (or other) tools without an allowlist.
        if allowed_tools:
            cmd += ["--allowedTools", " ".join(allowed_tools)]
        return cmd

    @override
    def _mcp_add_args(self, server: MCPServerConfig) -> list[str]:
        if server.transport == "stdio":
            return self._stdio_mcp_add_args(server)
        # Claude Code names the streamable-http transport "http".
        transport = (
            "http" if server.transport == "streamable-http" else server.transport
        )
        return ["--transport", transport, server.name, server.url or ""]

    @override
    def model_args(self, model: str) -> list[str]:
        if model.startswith("anthropic/"):
            model = model.removeprefix("anthropic/")
        return ["--model", model]

    @override
    def parse_output(self, raw: str) -> str:
        try:
            envelope = json.loads(raw)
            if isinstance(envelope, dict):
                if envelope.get("is_error"):
                    raise ValueError(
                        f"Claude CLI returned an error: {envelope.get('result', raw[:200])}"
                    )
                if "structured_output" in envelope:
                    return json.dumps(envelope["structured_output"])
        except (json.JSONDecodeError, TypeError):
            pass
        return raw


class CodexCLI(AgentCLI):
    name = "codex"
    cli_name = "codex"
    install_script = (
        "set -eu; "
        "if command -v apk >/dev/null 2>&1; then"
        "  npm install -g @openai/codex@latest;"
        " else"
        "  set -o pipefail;"
        "  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.2/install.sh | bash &&"
        '  export NVM_DIR="$HOME/.nvm" &&'
        '  . "$NVM_DIR/nvm.sh" || true &&'
        "  command -v nvm >/dev/null 2>&1 || { echo 'Error: NVM failed to load' >&2; exit 1; } &&"
        "  nvm install 22 && nvm alias default 22 && npm install -g @openai/codex@latest &&"
        '  for bin in node codex; do ln -sf "$(which $bin)" "/usr/local/bin/$bin" 2>/dev/null || true; done;'
        " fi && "
        "codex --version"
    )

    def __init__(self) -> None:
        self._schema_path: str | None = None

    @override
    def ensure_installed(self) -> None:
        super().ensure_installed()
        # codex does not read OPENAI_API_KEY on its own, so log in explicitly.
        # Both flags read the credential from stdin.
        access_token = os.environ.get("CODEX_ACCESS_TOKEN")
        api_key = os.environ.get("OPENAI_API_KEY")
        if access_token and (not api_key or force_oauth()):
            flag, credential = "--with-access-token", access_token
        elif api_key:
            flag, credential = "--with-api-key", api_key
        else:
            return
        subprocess.run(
            ["codex", "login", flag],
            input=credential,
            text=True,
            check=True,
            capture_output=True,
        )

    @override
    def build_command(
        self,
        prompt: str,
        schema: dict[str, Any],
        allowed_tools: tuple[str, ...] = (),
        cwd: str | None = None,
    ) -> list[str]:
        # cwd unused: codex exec honors the subprocess's own OS cwd as its
        # implicit workspace root.
        fd, self._schema_path = tempfile.mkstemp(suffix=".json")
        with os.fdopen(fd, "w") as f:
            json.dump(schema, f)
        return [
            "codex",
            "exec",
            prompt,
            "--output-schema",
            self._schema_path,
            "--skip-git-repo-check",
        ]

    @override
    def _mcp_add_args(self, server: MCPServerConfig) -> list[str]:
        if server.transport == "stdio":
            return self._stdio_mcp_add_args(server)
        if server.transport == "streamable-http":
            return [server.name, "--url", server.url or ""]
        raise ValueError(
            f"codex agent judge does not support '{server.transport}' MCP "
            f"servers (server '{server.name}'); use stdio or streamable-http."
        )

    @override
    def model_args(self, model: str) -> list[str]:
        return ["-m", model]

    @override
    def cleanup(self) -> None:
        if self._schema_path:
            Path(self._schema_path).unlink(missing_ok=True)
            self._schema_path = None


class AntigravityCLI(AgentCLI):
    """agy (Google's Antigravity CLI), Gemini-family judge backend.

        CLI surface confirmed live against `agy --help` (v1.1.20):
        `--print`/`-p`/`--prompt` (aliases, one-shot non-interactive),
        `--output-format {text,json,stream-json}`, `--json-schema <string-or-
        path>` ("enforce structured output"), `--model`, `--effort {low,medium,
        high}` (required only for effort-tiered models, e.g. gemini-*-flash --
        left unset here by default, matching this repo's other backends' "don't
        guess a flag the model doesn't need" convention), `--add-dir <path>`
        (repeatable), `--dangerously-skip-permissions`, `--print-timeout`
        (default 5m). No `login`/`auth` subcommand exists -- see below.

    No structured-output ENFORCEMENT parity with Codex/Claude has been
        live-verified end-to-end (no authenticated judge call had completed as
        of this backend's initial landing -- confirmed live for the first time
        on agencybench's re-gate, see that bundle's PROTOCOL.md). `--json-schema`
        is a real enforcement flag (unlike backends with no schema mechanism at
        all), passed alongside an explicit "your entire reply must be the JSON
        object, nothing else" suffix appended to every prompt (see
        `_REPLY_DISCIPLINE_SUFFIX` -- live analyze-work found agy models
        sometimes do artifact-style writes/answers that ignore plain
        instructions, e.g. saving to their own scratch dir instead of replying
        inline). `parse_output` is still left at the base-class default (return
        raw text) rather than assuming any particular envelope shape, so
        `parse_judge_response`'s own tolerant fenced/brace JSON extraction is
        what actually does the parsing -- the same posture this file already
        takes for CodexCLI (which also has no `parse_output` override).

        Workspace visibility: unlike Codex/Claude, agy does NOT treat its OS
        process cwd as an implicit workspace root for file operations (observed
        and worked around in harbor's own antigravity-cli agent adapter,
        `harbor/src/harbor/agents/installed/antigravity_cli.py` -- it explicitly
        passes `--add-dir "$(pwd)"` for exactly this reason). An earlier
        version of this backend passed `--add-dir "."`, relying on ordinary
        OS-level relative-path resolution -- CONFIRMED WRONG by a live probe
        (2026-08-25): with cwd set to a directory containing a uniquely-named
        marker file and `--add-dir "."`, agy searched `~/.gemini/
        antigravity-cli` (its own app-data dir) and then `~` first, and found
        the file only by shelling out `find / -name <file>` as a background
        task -- succeeding *only* because `--dangerously-skip-permissions`
        gave it unrestricted shell access. In a grading container without
        free shell access, this would silently fail to read the workspace and
        return a plausible-but-ungrounded score (the design-verifier skill's
        False-zeros table, "Judge cannot read the evidence") -- the worst
        failure mode a judge has, because nothing errors. Fixed: `cwd` is now
        threaded through from `_arun_agent_call` into `build_command(...,
        cwd=cwd)`, and this backend passes `os.path.abspath(cwd)` as
        `--add-dir` whenever `cwd` is provided (omitted entirely, falling
        back to agy's own default scratch workspace, only when the caller
        passes no cwd at all -- e.g. no `workspace` and no `judge.cwd` set).

        Auth: agy has no API-key/service-account path, only interactive browser
        OAuth, and (unlike Codex) no `agy login` subcommand rewardkit could
        drive headlessly. So `ensure_installed()` is NOT overridden -- exactly
        like ClaudeCodeCLI, credential provisioning is the caller's job before
        this backend's CLI ever runs: pre-seed a valid OAuth token file at
        `~/.gemini/antigravity-cli/antigravity-oauth-token` (mirrors
        `_seed_oauth_token` in the harbor agent adapter, which uploads a token
        obtained out-of-band the same way). test.sh in the calling bundle is
        the right place to do this seeding from an `AGY_AUTH_JSON` (raw file
        content, mirroring `CODEX_AUTH_JSON`'s convention) or `AGY_AUTH_JSON_PATH`
        (an already-in-container path) env var -- rewardkit itself has no
        upload_file-style channel to do this from inside build_command/
        ensure_installed the way Harbor's own agent adapter can.
    """

    name = "agy"
    cli_name = "agy"
    install_script = (
        "set -eu; "
        "curl -fsSL https://antigravity.google/cli/install.sh | bash && "
        'export PATH="$HOME/.local/bin:$PATH" && '
        "agy --version"
    )

    def __init__(self) -> None:
        self._schema_path: str | None = None

    # Hardening note (2026-08-25, from live analyze-work on agy trials): agy
    # models sometimes do artifact-style writes/answers that ignore plain
    # instructions -- e.g. saving to their own brain/scratch dir instead of
    # the path asked for (see docs/patches -- the analyze-agy.txt "path
    # discipline" precedent). --json-schema is a real enforcement flag here
    # (unlike the schema-in-prompt fallback other backends sometimes need),
    # but a belt-and-suspenders instruction costs nothing and directly
    # targets that failure mode for a judge call specifically.
    _REPLY_DISCIPLINE_SUFFIX = (
        "\n\nIMPORTANT: your entire reply must be the JSON object described "
        "above -- nothing else. Do not save it as a file, artifact, or note; "
        "do not add commentary before or after it; do not wrap it in prose."
    )

    # Confirmed live (2026-08-25): agy's --effort flag hard-rejects anything
    # outside this set at arg-parse time -- no "minimal" tier, unlike some
    # other agent CLIs' effort vocabularies.
    _VALID_EFFORTS = frozenset({"low", "medium", "high"})

    @override
    def build_command(
        self,
        prompt: str,
        schema: dict[str, Any],
        allowed_tools: tuple[str, ...] = (),
        cwd: str | None = None,
    ) -> list[str]:
        fd, self._schema_path = tempfile.mkstemp(suffix=".json")
        with os.fdopen(fd, "w") as f:
            json.dump(schema, f)
        cmd = [
            "agy",
            "--dangerously-skip-permissions",
        ]
        # Confirmed live (2026-08-25): agy does NOT honor its own OS process
        # cwd as an implicit workspace root, and a relative `--add-dir .`
        # does not resolve against it either -- must be the resolved
        # absolute path. No cwd at all (neither judge.cwd nor a workspace
        # dir was available to the caller) means there's nothing to point
        # --add-dir at; agy's own default scratch workspace applies instead
        # of guessing.
        if cwd:
            cmd += ["--add-dir", os.path.abspath(cwd)]
        cmd += [
            "--output-format",
            "json",
            "--json-schema",
            self._schema_path,
        ]
        # --effort is REQUIRED for effort-tiered models (e.g. gemini-*-flash)
        # and unsupported/unnecessary for others -- there is no way to infer
        # this from the model name alone, so it is never guessed, only read
        # from an explicit opt-in env var naming the model as effort-tiered.
        # Confirmed live (2026-08-25): agy hard-rejects at arg-parse time
        # (valid: low, medium, high -- no "minimal", unlike some other
        # backends' effort vocabularies), so an invalid value is rejected
        # here rather than passed through to fail inside the subprocess.
        effort = os.environ.get("AGY_MODEL_EFFORT")
        if effort:
            if effort not in self._VALID_EFFORTS:
                raise ValueError(
                    f"AGY_MODEL_EFFORT={effort!r} is not valid for agy; "
                    f"must be one of {sorted(self._VALID_EFFORTS)}"
                )
            cmd += ["--effort", effort]
        cmd += ["--print", prompt + self._REPLY_DISCIPLINE_SUFFIX]
        return cmd

    @override
    def _mcp_add_args(self, server: MCPServerConfig) -> list[str]:
        # `agy mcp add`/`agy mcp remove` exist (confirmed via `agy help mcp`)
        # but the exact argument shape for registering a server has not been
        # exercised live -- raise rather than guess and silently misregister.
        raise NotImplementedError(
            "agy agent judge does not yet support MCP servers -- 'agy mcp add' "
            "argument shape is unverified against a live server registration; "
            "add real args here once confirmed."
        )

    @override
    def model_args(self, model: str) -> list[str]:
        return ["--model", model]

    @override
    def parse_output(self, raw: str) -> str:
        # Confirmed live (2026-08-25, minimal test call): --output-format
        # json wraps the answer in an envelope --
        # {"conversation_id", "status", "response" (the model's raw text,
        # which may itself contain stray/duplicate JSON the model emitted
        # while "finishing" the turn -- not reliable to parse directly),
        # "duration_seconds", "num_turns", "structured_output" (the actual
        # --json-schema-conformant answer), "json_schema", "usage"} --
        # same "structured_output" envelope key ClaudeCodeCLI already
        # unwraps, coincidentally identical shape. Unwrap it the same way;
        # fall back to raw on any parse surprise so parse_judge_response's
        # own tolerant extraction still gets a chance.
        try:
            envelope = json.loads(raw)
            if isinstance(envelope, dict):
                if str(envelope.get("status", "SUCCESS")).upper() != "SUCCESS":
                    raise ValueError(
                        f"agy CLI returned status={envelope.get('status')!r}: {raw[:200]}"
                    )
                if "structured_output" in envelope:
                    return json.dumps(envelope["structured_output"])
        except (json.JSONDecodeError, TypeError):
            pass
        return raw

    @override
    def cleanup(self) -> None:
        if self._schema_path:
            Path(self._schema_path).unlink(missing_ok=True)
            self._schema_path = None


register_agent(ClaudeCodeCLI)
register_agent(CodexCLI)
register_agent(AntigravityCLI)
