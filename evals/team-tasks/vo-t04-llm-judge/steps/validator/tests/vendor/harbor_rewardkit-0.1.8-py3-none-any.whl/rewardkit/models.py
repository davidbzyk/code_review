"""All data types for rewardkit."""

from __future__ import annotations

import re
from typing import Any, Literal, Protocol, runtime_checkable

from pydantic import (
    BaseModel,
    ConfigDict,
    PrivateAttr,
    field_validator,
    model_validator,
)

Aggregation = Literal[
    "weighted_mean", "all_pass", "any_pass", "threshold", "required_pass"
]


@runtime_checkable
class OutputFormat(Protocol):
    def normalize(self, raw: float | bool | str) -> float: ...
    def prompt_fragment(self) -> str: ...
    def json_schema(self) -> dict[str, Any]: ...


class Binary(BaseModel):
    model_config = ConfigDict(frozen=True)

    def normalize(self, raw: float | bool | str) -> float:
        if isinstance(raw, bool):
            return 1.0 if raw else 0.0
        if isinstance(raw, str):
            return 1.0 if raw.strip().lower() in ("yes", "true", "1") else 0.0
        return 1.0 if raw else 0.0

    def prompt_fragment(self) -> str:
        return '"yes" or "no"'

    def json_schema(self) -> dict[str, Any]:
        return {"type": "string", "enum": ["yes", "no"]}


class Likert(BaseModel):
    model_config = ConfigDict(frozen=True)

    points: int = 5

    def normalize(self, raw: float | bool | str) -> float:
        if self.points <= 1:
            return 1.0
        return max(0.0, min(1.0, (float(raw) - 1) / (self.points - 1)))

    def prompt_fragment(self) -> str:
        return f"an integer from 1 to {self.points}"

    def json_schema(self) -> dict[str, Any]:
        return {"type": "integer"}


class Numeric(BaseModel):
    model_config = ConfigDict(frozen=True)

    min: float = 0.0
    max: float = 1.0

    def normalize(self, raw: float | bool | str) -> float:
        span = self.max - self.min
        if span <= 0:
            return 1.0
        return max(0.0, min(1.0, (float(raw) - self.min) / span))

    def prompt_fragment(self) -> str:
        return f"a number from {self.min} to {self.max}"

    def json_schema(self) -> dict[str, Any]:
        return {"type": "number"}


_SAFE_NAME_RE = re.compile(r"^[a-zA-Z0-9_-]{1,64}$")


def _slugify(text: str) -> str:
    # Normalize (lowercase + collapse non-alphanumerics) before truncating, not after —
    # truncating raw text first means two descriptions sharing a long, un-normalized
    # prefix collapse to the same 40-char slice and collide. Collisions can still
    # happen on shared normalized prefixes; Reward._validate() disambiguates those.
    slug = re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")
    return slug[:40].strip("_")


class Criterion(BaseModel):
    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    description: str
    output_format: OutputFormat = Binary()
    name: str | None = None
    id: str | None = None
    files: tuple[str, ...] = ()
    negate: bool = False
    optional: bool = False

    # Tracks whether `name` was set explicitly vs. auto-slugged, so
    # Reward._validate()'s duplicate-name disambiguation never touches a
    # name the caller chose deliberately. Not a model field: excluded from
    # model_dump()/schema, preserved across model_copy().
    _name_explicit: bool = PrivateAttr(default=False)

    @model_validator(mode="after")
    def _set_default_name(self) -> Criterion:
        if self.name is None:
            object.__setattr__(self, "name", _slugify(self.description))
        else:
            object.__setattr__(self, "_name_explicit", True)
        name = self.name
        # Providers that enforce structured-output schemas (e.g. Anthropic) reject
        # property keys outside ^[a-zA-Z0-9_-]{1,64}$. Catch invalid names at
        # criterion construction time so the error is clear, not a provider 400.
        if name and not _SAFE_NAME_RE.match(name):
            raise ValueError(
                f"Criterion name {name!r} must match ^[a-zA-Z0-9_-]{{1,64}}$ "
                "(required by structured-output providers). "
                "Use letters, digits, underscores, and hyphens only, max 64 chars."
            )
        return self


class Score(BaseModel):
    name: str
    value: float
    raw: Any
    weight: float = 1.0
    reasoning: str = ""
    error: str | None = None
    description: str = ""
    id: str | None = None
    negate: bool = False
    optional: bool = False

    def to_dict(self) -> dict[str, Any]:
        d = self.model_dump(include={"name", "value", "raw", "weight"})
        d["value"] = round(d["value"], 4)
        if self.id is not None:
            d = {"id": self.id, **d}
        if self.description:
            d["description"] = self.description
        if self.reasoning:
            d["reasoning"] = self.reasoning
        if self.error is not None:
            d["error"] = self.error
        # Surfaced so the inversion is auditable: raw is pre-flip, value is post-flip.
        if self.negate:
            d["negate"] = True
        if self.optional:
            d["optional"] = True
        return d


JudgeMode = Literal["batched", "individual"]

MCPTransport = Literal["stdio", "sse", "streamable-http"]


class MCPServerConfig(BaseModel):
    """MCP server for an agent judge; mirrors Harbor's task ``MCPServerConfig``."""

    model_config = ConfigDict(frozen=True)

    name: str
    transport: MCPTransport = "sse"
    url: str | None = None
    command: str | None = None
    args: tuple[str, ...] = ()
    allowed_tools: tuple[str, ...] = ()

    @field_validator("transport", mode="before")
    @classmethod
    def _normalize_transport(cls, value: Any) -> Any:
        return "streamable-http" if value == "http" else value

    @model_validator(mode="after")
    def _validate_transport_fields(self) -> MCPServerConfig:
        if self.transport in ("sse", "streamable-http") and not self.url:
            raise ValueError(f"'url' is required for transport '{self.transport}'")
        if self.transport == "stdio" and not self.command:
            raise ValueError("'command' is required for transport 'stdio'")
        return self

    def allowed_tool_names(self) -> tuple[str, ...]:
        if not self.allowed_tools:
            return (f"mcp__{self.name}",)
        return tuple(f"mcp__{self.name}__{tool}" for tool in self.allowed_tools)


class LLMJudge(BaseModel):
    model_config = ConfigDict(frozen=True)

    model: str = "anthropic/claude-sonnet-4-6"
    reasoning_effort: str = "medium"
    timeout: int = 300
    files: tuple[str, ...] = ()
    atif_trajectory: str | None = None
    reference: str | None = None
    mode: JudgeMode = "batched"


class AgentJudge(BaseModel):
    model_config = ConfigDict(frozen=True)

    agent: str = "claude-code"
    model: str | None = None
    timeout: int = 300
    cwd: str | None = None
    isolated: bool = False
    atif_trajectory: str | None = None
    reference: str | None = None
    mode: JudgeMode = "batched"
    mcp_servers: tuple[MCPServerConfig, ...] = ()

    @field_validator("agent")
    @classmethod
    def _validate_agent(cls, v: str) -> str:
        from rewardkit.agents import known_agents

        known = known_agents()
        if v not in known:
            names = ", ".join(sorted(known))
            raise ValueError(f"AgentJudge agent must be one of {names}, got '{v}'")
        return v
