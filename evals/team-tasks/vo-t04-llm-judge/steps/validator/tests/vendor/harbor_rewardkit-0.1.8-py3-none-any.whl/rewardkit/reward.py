from __future__ import annotations

import asyncio
import inspect
import re
import warnings
from contextlib import nullcontext
from pathlib import Path
from typing import Any, Awaitable, TypeVar

from rewardkit.isolation import aisolate, isolate
from rewardkit.judges import arun_agent, arun_llm
from rewardkit.models import Aggregation, AgentJudge, Criterion, LLMJudge, Score

_T = TypeVar("_T")

_MAX_NAME_LEN = 64
_UNSAFE_NAME_CHARS_RE = re.compile(r"[^a-zA-Z0-9_-]+")


def _sanitize_suffix(text: str) -> str:
    """Sanitize a criterion ``id`` (e.g. ``"1.1"``) for use as a name suffix."""
    return _UNSAFE_NAME_CHARS_RE.sub("_", text).strip("_")


def _join_with_suffix(base: str, suffix: str, max_len: int = _MAX_NAME_LEN) -> str:
    """Join *base* and *suffix* with ``_``, truncating *base* to keep the
    result within *max_len* — the suffix is what guarantees uniqueness, so it
    is never truncated away."""
    suffix = suffix[:max_len]
    room = max_len - len(suffix) - 1
    if room <= 0:
        return suffix
    return f"{base[:room]}_{suffix}"


def _accepts_workspace(fn: Any) -> bool:
    """Check if a callable accepts a ``workspace`` parameter."""
    try:
        return "workspace" in inspect.signature(fn).parameters
    except (ValueError, TypeError):
        return False


async def _guarded(coro: Awaitable[_T], sem: asyncio.Semaphore | None) -> _T:
    """Await *coro*, acquiring *sem* first if provided."""
    if sem:
        async with sem:
            return await coro
    return await coro


def _weighted_mean(scores: list[Score]) -> float:
    total_weight = sum(s.weight for s in scores)
    if total_weight == 0:
        return 0.0
    return sum(s.value * s.weight for s in scores) / total_weight


def aggregate_scores(
    scores: list[Score], aggregation: Aggregation, threshold: float = 0.5
) -> float:
    if not scores:
        return 0.0
    if aggregation == "all_pass":
        return 1.0 if all(s.value > 0 for s in scores) else 0.0
    if aggregation == "any_pass":
        return 1.0 if any(s.value > 0 for s in scores) else 0.0
    if aggregation == "required_pass":
        required = [s for s in scores if not s.optional]
        if not required:
            warnings.warn(
                "required_pass aggregation but all criteria are optional; scoring 0.0",
                stacklevel=2,
            )
            return 0.0
        return 1.0 if all(s.value > 0 for s in required) else 0.0
    mean = _weighted_mean(scores)
    if aggregation == "threshold":
        return 1.0 if mean >= threshold else 0.0
    return mean


class Reward:
    def __init__(
        self,
        criteria: list[Any],
        weights: list[float] | None = None,
        judge: LLMJudge | AgentJudge | None = None,
        workspace: str | Path | None = None,
        name: str = "",
        reward_weight: float = 1.0,
        system_prompt: str | None = None,
        aggregation: Aggregation = "weighted_mean",
        threshold: float = 0.5,
    ) -> None:
        self.criteria = criteria
        self.weights = weights
        self.judge = judge
        self.workspace = Path(workspace) if workspace else None
        self.name = name
        self.reward_weight = reward_weight
        self.system_prompt = system_prompt
        self.aggregation: Aggregation = aggregation
        self.threshold = threshold
        self.scores: list[Score] = []
        self.judge_output: str = ""
        self.warnings: list[str] = []

        self._validate()

    def _validate(self) -> None:
        if self.judge is None:
            for c in self.criteria:
                if isinstance(c, Criterion):
                    raise TypeError(
                        "Criterion instances require a judge. "
                        "Use callable functions for programmatic evaluation."
                    )
                if not callable(c):
                    raise TypeError(
                        f"Programmatic criteria must be callable, got {type(c).__name__}"
                    )
        else:
            for c in self.criteria:
                if not isinstance(c, Criterion):
                    raise TypeError(
                        "Judge-based evaluation requires Criterion instances, not callables."
                    )
            self._dedupe_criterion_names()

        if self.weights is not None and len(self.weights) != len(self.criteria):
            raise ValueError(
                f"weights length ({len(self.weights)}) "
                f"must match criteria length ({len(self.criteria)})"
            )

    def _dedupe_criterion_names(self) -> None:
        """Rename criteria whose name collides with another's in this Reward.

        Judge response schemas and parsing key criteria by ``name`` (see
        ``judges._build_response_schema`` / ``parse_judge_response``): two
        criteria with the same name collapse into one schema property and one
        parsed Score, silently corrupting aggregation. This is common when
        ``name`` is auto-slugged from ``description`` — template-generated
        rubrics often share a long stem that differs only near the end.

        Only auto-generated names are touched; a criterion with an explicit
        ``name=`` is never renamed. Disambiguation prefers the criterion's
        own ``id`` (stable, present on affected datasets' rubrics) as a
        suffix, falling back to the criterion's list index — both are fixed
        properties of the criterion, so the same rubric always yields the
        same names.
        """
        counts: dict[str, int] = {}
        for c in self.criteria:
            counts[c.name] = counts.get(c.name, 0) + 1
        if all(n <= 1 for n in counts.values()):
            return

        used_names = {
            c.name for c in self.criteria if counts[c.name] <= 1 or c._name_explicit
        }
        new_criteria = list(self.criteria)
        collided: list[str] = []
        for i, c in enumerate(new_criteria):
            if counts[c.name] <= 1 or c._name_explicit:
                continue
            suffix = _sanitize_suffix(c.id) if c.id else str(i)
            candidate = _join_with_suffix(c.name, suffix)
            attempt = 1
            while candidate in used_names:
                attempt += 1
                candidate = _join_with_suffix(c.name, f"{suffix}_{attempt}")
            used_names.add(candidate)
            collided.append(f"{c.name!r} -> {candidate!r}")
            new_criteria[i] = c.model_copy(update={"name": candidate})
        self.criteria = new_criteria
        if collided:
            warnings.warn(
                f"Reward {self.name!r}: duplicate criterion names detected "
                f"(likely truncated auto-generated slugs on similar/long "
                f"descriptions); disambiguated by suffixing the criterion id "
                f"or list index: {', '.join(collided)}. Set an explicit "
                f"`name=` on each criterion to avoid this.",
                stacklevel=3,
            )

    def _eval_criterion(self, i: int, fn: Any, workspace: Path | None) -> Score:
        """Evaluate a single criterion function and return a Score."""
        weight = self.weights[i] if self.weights else 1.0
        fn_name = getattr(fn, "_criterion_name", None) or getattr(
            fn, "__name__", f"criterion_{i}"
        )
        description = (
            getattr(fn, "_criterion_description", None)
            or getattr(fn, "__doc__", None)
            or fn_name
        )
        try:
            if workspace is not None and _accepts_workspace(fn):
                raw = fn(workspace)
            else:
                raw = fn()

            if isinstance(raw, bool):
                value = 1.0 if raw else 0.0
            elif isinstance(raw, (int, float)):
                value = float(raw)
                if value > 1.0:
                    warnings.warn(
                        f"Criterion {fn_name!r} returned {value:.4f} which exceeds 1.0; "
                        f"score will not be clamped — verify your criterion logic.",
                        stacklevel=2,
                    )
                elif value < 0.0:
                    warnings.warn(
                        f"Criterion {fn_name!r} returned {value:.4f} which is below 0.0; "
                        f"score will not be clamped — verify your criterion logic.",
                        stacklevel=2,
                    )
            else:
                raise TypeError(
                    f"Criterion {fn_name!r} returned {type(raw).__name__}, "
                    f"expected bool, int, or float."
                )

            return Score(
                name=fn_name,
                value=value,
                raw=raw,
                weight=weight,
                description=description,
            )
        except ImportError as e:
            raise ImportError(
                f"Criterion {fn_name!r} failed due to missing dependency: {e}. "
                f"Install the required extra (e.g. uv add harbor-rewardkit[all])."
            ) from e
        except Exception as e:
            raise RuntimeError(f"Criterion {fn_name!r} failed: {e}") from e

    def _run_one(self, i: int, fn: Any) -> Score:
        """Run a single criterion, with isolation if configured."""
        is_isolated = getattr(fn, "_criterion_isolated", False)
        if self.workspace and is_isolated:
            with isolate(self.workspace) as ws:
                return self._eval_criterion(i, fn, ws)
        return self._eval_criterion(i, fn, self.workspace)

    async def arun(self, sem: asyncio.Semaphore | None = None) -> list[Score]:
        try:
            return await self._arun_inner(sem)
        except ExceptionGroup as eg:
            # Unwrap TaskGroup ExceptionGroup to surface the first real error.
            first = eg.exceptions[0]
            raise RuntimeError(f"Reward {self.name!r} failed: {first}") from first
        except Exception as e:
            raise RuntimeError(f"Reward {self.name!r} failed: {e}") from e

    async def _arun_inner(self, sem: asyncio.Semaphore | None) -> list[Score]:
        if self.judge is None:
            tasks: list[asyncio.Task[Score]] = []
            async with asyncio.TaskGroup() as tg:
                for i, fn in enumerate(self.criteria):
                    coro = asyncio.to_thread(self._run_one, i, fn)
                    tasks.append(tg.create_task(_guarded(coro, sem)))
            scores = [t.result() for t in tasks]

        elif isinstance(self.judge, LLMJudge):
            coro = arun_llm(
                self.judge,
                self.criteria,
                self.weights,
                system_prompt=self.system_prompt,
            )
            scores, self.judge_output, self.warnings = await _guarded(coro, sem)

        elif isinstance(self.judge, AgentJudge):
            agent_judge = self.judge

            async def _run_agent() -> tuple[list[Score], str, list[str]]:
                ws = self.workspace
                ctx = aisolate(ws) if (ws and agent_judge.isolated) else nullcontext(ws)
                async with ctx as effective_ws:
                    return await arun_agent(
                        agent_judge,
                        self.criteria,
                        self.weights,
                        workspace=effective_ws,
                        system_prompt=self.system_prompt,
                    )

            scores, self.judge_output, self.warnings = await _guarded(_run_agent(), sem)

        else:
            raise TypeError(f"Unknown judge type: {type(self.judge)}")

        self.scores = scores
        return scores

    def run(self) -> list[Score]:
        return asyncio.run(self.arun())

    @property
    def score(self) -> float:
        return aggregate_scores(self.scores, self.aggregation, self.threshold)

    def to_detail_dict(self, score: float) -> dict[str, Any]:
        d: dict[str, Any] = {
            "score": score,
            "criteria": [s.to_dict() for s in self.scores],
        }
        if self.judge is not None:
            d["kind"] = "agent" if isinstance(self.judge, AgentJudge) else "llm"
            d["judge"] = self.judge.model_dump()
            d["judge_output"] = self.judge_output
        else:
            d["kind"] = "programmatic"
        if self.warnings:
            d["warnings"] = self.warnings
        return d
