"""LLM and agent judges for rewardkit."""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
import re
from importlib import resources
from pathlib import Path
from typing import Any

import litellm

from rewardkit.agents import force_oauth
from rewardkit.models import AgentJudge, Criterion, LLMJudge, Score

logger = logging.getLogger(__name__)

_TEMPLATES: dict[str, str] = {}


def _resolve_credentials(model: str) -> dict[str, Any]:
    """Resolve extra credential kwargs to pass to ``litellm.acompletion``.

    Most providers need nothing here — litellm reads their standard env vars
    itself. Provider-specific resolution is added below as needed.
    """
    oauth = _anthropic_subscription_key(model)
    if oauth is not None:
        return {"api_key": oauth}
    return {}


def _is_anthropic_direct_model(model: str) -> bool:
    """True for models that litellm routes directly to Anthropic.

    Includes ``anthropic/...`` prefixed and bare ``claude-...`` names.
    Provider-routed variants (Bedrock, Vertex, OpenRouter) use their own credentials.
    """
    return model.startswith("anthropic/") or (
        "/" not in model and model.lower().startswith("claude")
    )


def _anthropic_subscription_key(model: str) -> str | None:
    """Return the Claude subscription OAuth token for litellm to use as the api_key.

    LiteLLM recognises ``sk-ant-oat*`` tokens and sends them as
    ``Authorization: Bearer``. ``ANTHROPIC_API_KEY`` wins when both are set,
    unless ``REWARDKIT_FORCE_OAUTH`` is set to prefer the subscription token.

    Obtain a token via ``claude setup-token`` (Claude Pro/Max/Team/Enterprise
    subscription required); set it as ``CLAUDE_CODE_OAUTH_TOKEN`` in the
    environment. See https://code.claude.com/docs/en/authentication for details.
    """
    if not _is_anthropic_direct_model(model):
        return None
    oauth = os.environ.get("CLAUDE_CODE_OAUTH_TOKEN")
    if not oauth:
        return None
    if os.environ.get("ANTHROPIC_API_KEY") and not force_oauth():
        return None
    return oauth


def _load_template(name: str) -> str:
    if name not in _TEMPLATES:
        _TEMPLATES[name] = (
            resources.files("rewardkit.prompts").joinpath(f"{name}.md").read_text()
        )
    return _TEMPLATES[name]


def _build_criteria_block(criteria: list[Criterion]) -> str:
    lines: list[str] = []
    for c in criteria:
        fmt = c.output_format
        lines.append(f"- '{c.name}': {c.description} (score: {fmt.prompt_fragment()})")
    lines.append("")
    lines.append("Respond with a JSON object. Example:")
    if len(criteria) == 1:
        example: dict[str, Any] = {"score": 1, "reasoning": "..."}
    else:
        example = {c.name: {"score": 1, "reasoning": "..."} for c in criteria}
    lines.append(json.dumps(example, indent=2))
    return "\n".join(lines)


def _criterion_entry_schema(c: Criterion) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "score": c.output_format.json_schema(),
            "reasoning": {"type": "string"},
        },
        "required": ["score", "reasoning"],
        "additionalProperties": False,
    }


def _build_response_schema(criteria: list[Criterion]) -> dict[str, Any]:
    """Build a JSON Schema enforcing the judge's response structure.

    A single criterion uses the flat ``{"score": ..., "reasoning": ...}`` shape. Keeping
    lets Anthropic reuse its compiled grammar instead of recompiling per
    criterion, which would otherwise hit the 20-per-minute compile limit on
    judges with many criteria.
    """
    if len(criteria) == 1:
        return _criterion_entry_schema(criteria[0])

    props: dict[str, Any] = {
        (c.name or "criterion"): _criterion_entry_schema(c) for c in criteria
    }
    return {
        "type": "object",
        "properties": props,
        "required": list(props.keys()),
        "additionalProperties": False,
    }


def build_prompt(
    criteria: list[Criterion],
    template: str | None = None,
    kind: str = "llm",
) -> str:
    criteria_block = _build_criteria_block(criteria)
    tmpl = template if template is not None else _load_template(kind)
    return tmpl.replace("{criteria}", criteria_block)


_SKIP_DIRS = frozenset({"__pycache__", "node_modules", ".git"})
_MAX_FILE_SIZE = 1024 * 1024  # 1MB

_IMAGE_EXTENSIONS = frozenset({".jpg", ".jpeg", ".png", ".gif", ".webp"})
_IMAGE_MEDIA_TYPES: dict[str, str] = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".webp": "image/webp",
}
_DOCUMENT_EXTENSIONS = frozenset(
    {".pdf", ".docx", ".pptx", ".xlsx", ".xls", ".msg", ".epub", ".html", ".htm"}
)
ContentBlock = dict[str, Any]


def _convert_with_markitdown(p: Path) -> str:
    try:
        from markitdown import MarkItDown
    except ImportError as e:
        raise ImportError(
            f"Reading {p.suffix} files requires the 'documents' extra. "
            f"Install with: uv add harbor-rewardkit[documents]"
        ) from e
    return MarkItDown().convert(str(p)).text_content


def _read_file_blocks(p: Path, label: str) -> list[ContentBlock]:
    """Read a single file into content blocks. Returns empty list on skip."""
    if p.name.startswith("."):
        return []
    try:
        size = p.stat().st_size
    except OSError:
        return [{"type": "text", "text": f"--- {label} ---\n[unreadable]"}]

    if size > _MAX_FILE_SIZE:
        return [{"type": "text", "text": f"--- {label} ---\n[skipped: file too large]"}]

    suffix = p.suffix.lower()
    if suffix in _IMAGE_EXTENSIONS:
        try:
            data = base64.b64encode(p.read_bytes()).decode("ascii")
            media_type = _IMAGE_MEDIA_TYPES[suffix]
            return [
                {"type": "text", "text": f"--- {label} ---"},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:{media_type};base64,{data}"},
                },
            ]
        except OSError:
            return [{"type": "text", "text": f"--- {label} ---\n[unreadable image]"}]

    if suffix in _DOCUMENT_EXTENSIONS:
        text = _convert_with_markitdown(p)
        return [{"type": "text", "text": f"--- {label} ---\n{text}"}]

    # Try reading as text: binary files raise UnicodeDecodeError and are skipped.
    try:
        return [{"type": "text", "text": f"--- {label} ---\n{p.read_text()}"}]
    except (UnicodeDecodeError, OSError):
        return []


def _build_user_content(files: tuple[str, ...] | list[str]) -> list[ContentBlock]:
    if not files:
        return []
    blocks: list[ContentBlock] = []
    for path_str in files:
        p = Path(path_str)
        if not p.exists():
            blocks.append({"type": "text", "text": f"--- {path_str} ---\n[not found]"})
            continue
        if p.is_file():
            blocks.extend(_read_file_blocks(p, path_str))
        elif p.is_dir():
            for child in sorted(p.iterdir()):
                if child.is_dir() and (
                    child.name in _SKIP_DIRS or child.name.startswith(".")
                ):
                    continue
                if child.is_file():
                    blocks.extend(_read_file_blocks(child, str(child)))
    return blocks


def _text_from_blocks(blocks: list[ContentBlock]) -> str:
    """Extract text-only content from blocks (for token counting)."""
    return "\n\n".join(b["text"] for b in blocks if b.get("type") == "text")


def _build_reference_blocks(reference: str | None) -> list[ContentBlock]:
    """Build the '## Reference Solution' block(s) a judge sees when
    ``judge.reference`` is set. Shared by the LLM and agent judge paths
    (``_arun_llm_call`` / ``_arun_agent_call``) so both honor a configured
    reference identically -- an unset or unreadable reference is a no-op for
    either path, never an empty header.
    """
    if not reference:
        return []
    ref_blocks = _build_user_content((reference,))
    if not ref_blocks:
        return []
    return [
        {
            "type": "text",
            "text": "## Reference Solution\nThe following is a reference solution. Compare the agent's work against it:",
        },
        *ref_blocks,
    ]


_MAX_JUDGE_RETRIES = 3


def parse_judge_response(
    text: str,
    criteria: list[Criterion],
    weights: list[float] | None,
) -> list[Score]:
    json_match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if json_match:
        data = json.loads(json_match.group(1))
    else:
        brace_match = re.search(r"\{.*\}", text, re.DOTALL)
        if brace_match:
            data = json.loads(brace_match.group(0))
        else:
            raise ValueError(f"Could not parse JSON from judge response: {text[:200]}")

    # A single criterion returns the flat {"score": ..., "reasoning": ...} shape; wrap it
    # under its name so the loop below treats one and many criteria alike. Detect
    # the flat shape by its non-dict "score" leaf (not by key name), so a
    # criterion literally named "score" still parses.
    if len(criteria) == 1 and "score" in data and not isinstance(data["score"], dict):
        data = {(criteria[0].name or "criterion_0"): data}

    scores: list[Score] = []
    for i, c in enumerate(criteria):
        cname = c.name or f"criterion_{i}"
        entry = data.get(cname)
        if not isinstance(entry, dict) or "score" not in entry:
            raise ValueError(
                f"Criterion {cname!r}: expected dict with 'score' and 'reasoning', "
                f"got {type(entry).__name__}: {str(entry)[:100]}"
            )
        raw_score = entry["score"]
        reasoning = entry.get("reasoning", "")
        value = c.output_format.normalize(raw_score)
        if c.negate:
            value = 1.0 - value
        weight = weights[i] if weights else 1.0
        scores.append(
            Score(
                name=cname,
                value=value,
                raw=raw_score,
                weight=weight,
                reasoning=reasoning,
                description=c.description,
                id=c.id,
                negate=c.negate,
                optional=c.optional,
            )
        )
    return scores


def _timeout_scores(
    criteria: list[Criterion],
    weights: list[float] | None,
    timeout: int,
) -> list[Score]:
    """Errored 0.0 scores for a judge call that timed out."""
    return [
        Score(
            name=c.name or f"criterion_{i}",
            value=0.0,
            raw=None,
            weight=weights[i] if weights else 1.0,
            error=f"judge timed out after {timeout}s",
            description=c.description,
            id=c.id,
            negate=c.negate,
            optional=c.optional,
        )
        for i, c in enumerate(criteria)
    ]


async def arun_llm(
    judge: LLMJudge,
    criteria: list[Criterion],
    weights: list[float] | None = None,
    system_prompt: str | None = None,
) -> tuple[list[Score], str, list[str]]:
    if judge.mode == "individual":
        return await _arun_llm_individual(judge, criteria, weights, system_prompt)
    return await _arun_llm_call(judge, criteria, weights, judge.files, system_prompt)


async def _arun_llm_individual(
    judge: LLMJudge,
    criteria: list[Criterion],
    weights: list[float] | None,
    system_prompt: str | None,
) -> tuple[list[Score], str, list[str]]:
    async with asyncio.TaskGroup() as tg:
        tasks = [
            tg.create_task(
                _arun_llm_call(
                    judge,
                    [c],
                    [weights[i]] if weights else None,
                    c.files or judge.files,
                    system_prompt,
                )
            )
            for i, c in enumerate(criteria)
        ]
    scores: list[Score] = []
    outputs: list[str] = []
    warns: list[str] = []
    for c, t in zip(criteria, tasks):
        s, raw, w = t.result()
        scores.extend(s)
        outputs.append(f"--- {c.name} ---\n{raw}")
        warns.extend(w)
    return scores, "\n\n".join(outputs), warns


async def _arun_llm_call(
    judge: LLMJudge,
    criteria: list[Criterion],
    weights: list[float] | None,
    files: tuple[str, ...],
    system_prompt: str | None,
) -> tuple[list[Score], str, list[str]]:
    warn_list: list[str] = []
    if system_prompt:
        prompt = build_prompt(criteria, template=system_prompt)
    elif judge.atif_trajectory:
        prompt = build_prompt(criteria, kind="llm_trajectory")
    else:
        prompt = build_prompt(criteria)

    user_blocks = _build_user_content(files)
    user_blocks.extend(_build_reference_blocks(judge.reference))
    if judge.atif_trajectory:
        from rewardkit.trajectory import format_trajectory

        model_info = litellm.get_model_info(judge.model)
        max_input_tokens: int = model_info.get("max_input_tokens") or 200_000
        prompt_tokens = len(litellm.encode(model=judge.model, text=prompt))
        user_text = _text_from_blocks(user_blocks)
        user_tokens = (
            len(litellm.encode(model=judge.model, text=user_text)) if user_text else 0
        )
        available_tokens = max_input_tokens - prompt_tokens - user_tokens - 32_000

        if available_tokens <= 0:
            raise ValueError(
                f"Trajectory too large to include in judge prompt: "
                f"no token budget remaining "
                f"(prompt={prompt_tokens}, user={user_tokens}, "
                f"limit={max_input_tokens})."
            )

        traj_text = format_trajectory(
            judge.atif_trajectory,
            max_tokens=available_tokens,
            model=judge.model,
            warnings_out=warn_list,
        )
        user_blocks.append({"type": "text", "text": traj_text})

    messages: list[dict[str, Any]] = [{"role": "system", "content": prompt}]
    if user_blocks:
        messages.append({"role": "user", "content": user_blocks})
    credentials = _resolve_credentials(judge.model)
    for attempt in range(_MAX_JUDGE_RETRIES):
        try:
            resp = await litellm.acompletion(
                model=judge.model,
                **credentials,
                messages=messages,
                response_format={
                    "type": "json_schema",
                    "json_schema": {
                        "name": "judge_response",
                        "schema": _build_response_schema(criteria),
                        "strict": True,
                    },
                },
                timeout=judge.timeout,
                reasoning_effort=judge.reasoning_effort,
            )
        except litellm.Timeout:
            warn_list.append(
                f"judge timed out after {judge.timeout}s; recording affected "
                "criteria as 0.0"
            )
            return _timeout_scores(criteria, weights, judge.timeout), "", warn_list
        raw_output = resp.choices[0].message.content
        try:
            scores = parse_judge_response(raw_output, criteria, weights)
            return scores, raw_output, warn_list
        except ValueError:
            if attempt == _MAX_JUDGE_RETRIES - 1:
                raise
            logger.debug(
                "Judge response did not match schema, retrying (%d/%d)",
                attempt + 1,
                _MAX_JUDGE_RETRIES,
            )
    raise RuntimeError("Unreachable")


async def arun_agent(
    judge: AgentJudge,
    criteria: list[Criterion],
    weights: list[float] | None = None,
    workspace: str | Path | None = None,
    system_prompt: str | None = None,
) -> tuple[list[Score], str, list[str]]:
    if judge.mcp_servers:
        from rewardkit.agents import get_agent

        backend = get_agent(judge.agent)
        backend.ensure_installed()
        cwd = judge.cwd or (
            str(workspace) if workspace and Path(workspace).is_dir() else None
        )
        backend.add_mcp_servers(judge.mcp_servers, cwd=cwd)
    if judge.mode == "individual":
        return await _arun_agent_individual(
            judge, criteria, weights, workspace, system_prompt
        )
    return await _arun_agent_call(judge, criteria, weights, workspace, system_prompt)


async def _arun_agent_individual(
    judge: AgentJudge,
    criteria: list[Criterion],
    weights: list[float] | None,
    workspace: str | Path | None,
    system_prompt: str | None,
) -> tuple[list[Score], str, list[str]]:
    """Grade each criterion in its own agent call, sequentially.

    Unlike the LLM individual path (which fans criteria out concurrently),
    agent calls are heavy local CLI subprocesses, so they run one at a time;
    N parallel agent processes would exhaust a small verifier container.
    """
    scores: list[Score] = []
    outputs: list[str] = []
    warns: list[str] = []
    for i, c in enumerate(criteria):
        s, raw, w = await _arun_agent_call(
            judge,
            [c],
            [weights[i]] if weights else None,
            workspace,
            system_prompt,
        )
        scores.extend(s)
        outputs.append(f"--- {c.name} ---\n{raw}")
        warns.extend(w)
    return scores, "\n\n".join(outputs), warns


async def _arun_agent_call(
    judge: AgentJudge,
    criteria: list[Criterion],
    weights: list[float] | None,
    workspace: str | Path | None,
    system_prompt: str | None,
) -> tuple[list[Score], str, list[str]]:
    from rewardkit.agents import get_agent

    warn_list: list[str] = []
    if system_prompt:
        prompt = build_prompt(criteria, template=system_prompt)
    else:
        prompt = build_prompt(criteria, kind="agent")
    # Agent judges explore their cwd themselves (see prompts/agent.md), but
    # judge.reference commonly lives outside cwd (e.g. tests/mean_score/
    # reference.md vs a workspace cwd) -- without this the agent has no
    # reliable way to find it, and previously never got told to look, unlike
    # the LLM path (_arun_llm_call) which has always included it explicitly.
    ref_text = _text_from_blocks(_build_reference_blocks(judge.reference))
    if ref_text:
        prompt += f"\n\n{ref_text}"
    if judge.atif_trajectory:
        prompt += f"\n\nThe agent's trajectory is stored at: {judge.atif_trajectory}"

    schema = _build_response_schema(criteria)
    backend = get_agent(judge.agent)
    cwd = judge.cwd or (
        str(workspace) if workspace and Path(workspace).is_dir() else None
    )

    backend.ensure_installed()

    allowed_tools = tuple(
        name for server in judge.mcp_servers for name in server.allowed_tool_names()
    )
    cmd = backend.build_command(prompt, schema, allowed_tools=allowed_tools, cwd=cwd)
    if judge.model:
        cmd.extend(backend.model_args(judge.model))

    try:
        for attempt in range(_MAX_JUDGE_RETRIES):
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=cwd,
            )
            try:
                stdout, _stderr = await asyncio.wait_for(
                    proc.communicate(), timeout=judge.timeout
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.communicate()
                warn_list.append(
                    f"judge timed out after {judge.timeout}s; recording affected "
                    "criteria as 0.0"
                )
                return _timeout_scores(criteria, weights, judge.timeout), "", warn_list
            raw_output = stdout.decode()
            if proc.returncode != 0:
                stderr_text = _stderr.decode().strip() if _stderr else ""
                if attempt == _MAX_JUDGE_RETRIES - 1:
                    raise ValueError(
                        f"Agent CLI '{backend.cli_name}' exited with code "
                        f"{proc.returncode}: {stderr_text or raw_output[:200]}"
                    )
                logger.debug(
                    "Agent judge CLI exited with code %d, retrying (%d/%d)",
                    proc.returncode,
                    attempt + 1,
                    _MAX_JUDGE_RETRIES,
                )
                continue
            raw_output = backend.parse_output(raw_output)
            try:
                scores = parse_judge_response(raw_output, criteria, weights)
                return scores, raw_output, warn_list
            except ValueError:
                if attempt == _MAX_JUDGE_RETRIES - 1:
                    raise
                logger.debug(
                    "Agent judge response did not match schema, retrying (%d/%d)",
                    attempt + 1,
                    _MAX_JUDGE_RETRIES,
                )
        raise RuntimeError("Unreachable")
    finally:
        backend.cleanup()
